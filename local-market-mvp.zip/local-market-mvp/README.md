# LocalMarket — Hyperlocal Marketplace MVP

Ek chhota Streamlit app jisme:
- **Buyer** apni location se nazdeek shopkeepers se item order kar sakta hai
- **Shopkeeper** apna stock list karta hai, wallet recharge karta hai, orders manage karta hai
- **Delivery Boy** orders accept karke deliver karta hai
- **Admin** platform ki total earning/stats dekh sakta hai

Payment seedha shopkeeper ke UPI ID par jata hai (QR code se). Platform commission:
- Wallet **recharge** par 2% (edit karo `db.py` mein `RECHARGE_COMMISSION_PERCENT`)
- Har **order** par 1% (edit karo `db.py` mein `ORDER_COMMISSION_PERCENT`)
- Delivery charge slab (edit karo `utils.py` mein `calculate_delivery_charge`)

---

## 1. Apne computer par test karna (optional)

```bash
pip install -r requirements.txt
streamlit run app.py
```

Browser mein `http://localhost:8501` khul jayega.

---

## 2. GitHub par code daalna

Agar pehli baar GitHub use kar rahe ho:

1. https://github.com par account banao (agar nahi hai)
2. Naya repository banao (top-right `+` → **New repository**) — naam do jaise `local-market-mvp`, **Public** rakho, "Add README" ko UNCHECK rakho (kyunki hamare paas already hai)
3. Apne computer/terminal mein is folder ke andar jaake ye commands chalao:

```bash
cd local-market-mvp
git init
git add .
git commit -m "Initial commit - LocalMarket MVP"
git branch -M main
git remote add origin https://github.com/<aapka-username>/local-market-mvp.git
git push -u origin main
```

(`<aapka-username>` ki jagah apna GitHub username daalo. Pehli baar push karte waqt GitHub login maang sakta hai — Personal Access Token banana pad sakta hai: GitHub → Settings → Developer settings → Personal access tokens.)

---

## 3. Streamlit Community Cloud par deploy karna (FREE)

1. https://share.streamlit.io par jao aur apne GitHub account se sign in karo
2. **"Create app"** ya **"New app"** button dabao
3. Apni repository select karo (`local-market-mvp`)
4. Branch: `main`, Main file path: `app.py`
5. **"Deploy"** dabao — 1-2 minute mein aapka app live ho jayega, ek URL milega jaise:
   `https://<something>.streamlit.app`

Bas! Ye link kisi ke saath bhi share kar sakte ho.

### Admin passcode set karna (recommended)
Deploy hone ke baad app ke **Settings → Secrets** mein jaake ye add karo:
```
ADMIN_PASSCODE = "apna-secret-passcode"
```
(Nahi kiya to default `admin123` use hoga — production mein zaroor badlo.)

---

## ⚠️ Important limitations (MVP hai, production nahi)

1. **Database reset ho sakta hai**: Streamlit Cloud free tier par `market.db` (SQLite) file permanently persist nahi hoti — app restart/redeploy hone par data reset ho sakta hai. Real launch se pehle isse **Supabase (Postgres)**, **Turso**, ya kisi cloud database mein migrate karna.
2. **Payment verification manual hai**: Abhi QR scan hone ke baad system ko pata nahi chalta ki payment actually hui ya nahi (UPI apps is tarah ka automatic confirmation nahi dete without a payment gateway). Real app ke liye **Razorpay/Cashfree UPI payment gateway** integrate karna hoga jo payment confirm hone par webhook bhejta hai.
3. **Location accuracy**: Auto-detect browser permission maangta hai; agar user deny kare to manual lat/lng dalna padta hai.
4. **Security**: Password hashing basic hai (SHA-256). Production ke liye proper auth (bcrypt + salt, ya Firebase Auth / Supabase Auth) use karo.
5. **Scale**: Streamlit ek chhoti app ke liye perfect hai (hundreds of users). Lakhs of users ke liye aage chalke proper backend (FastAPI/Django + mobile app) chahiye hoga.

---

## Files (single-page app — koi page-switch flicker nahi)
```
local-market-mvp/
├── app.py                          # SAB KUCH ek hi file mein (Home + Buyer + Shopkeeper + Delivery Boy + Admin)
├── db.py                           # Database (SQLite) + business logic
├── utils.py                        # Distance, delivery charge, UPI QR
├── requirements.txt
└── README.md
```

**Note**: Pehle version mein `pages/` folder tha jisse Streamlit apna default multi-page
sidebar navigation banata tha — usse page switch karte waqt ek chhota black-and-white
flicker aata tha. Ab poori app ek single `app.py` file mein hai; role switch karne ke
liye sirf ek sidebar radio button use hota hai (`st.session_state` se), poora page reload
nahi hota, isliye flicker nahi aata.
